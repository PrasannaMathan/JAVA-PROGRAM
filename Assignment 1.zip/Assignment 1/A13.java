import java.lang.*;
class A13
    {
       public static void main(String args[])
           {
              int a=3;
              int b=5;
             int c = a;
                 a = b;
                 b = c;
               System.out.println("After swapping the integers are"+a+b);
               
           }
    }