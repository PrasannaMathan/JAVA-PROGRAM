import java.lang.*;
class A12
    {
       public static void main(String args[])
           {
              float c =36;
              float f=((9*c)/5+32);
               System.out.println("The celcius in fahrenhite is"+f);
               
           }
    }