import java.lang.*;
class A11
    {
       public static void main(String args[])
           {
              int l=8;
              int b=5;
              int h=4;
               System.out.println("Area of the squre is"+(l*l));
               System.out.println("Area of the rectangle is"+(l*b));
              System.out.println("Volume of the cube  is"+(l*l*l));
           }
    }