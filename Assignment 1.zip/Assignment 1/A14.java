import java.lang.*;
class A14
    {
       public static void main(String args[])
           {
              int a=3;
              int b=5;
             
              a= a ^ b;
              b= a ^ b;
              a= a ^ b;

              
               System.out.println("After swapping the integers are"+a+" "+b);
               
           }
    }