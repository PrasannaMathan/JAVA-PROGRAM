import java.lang.*;
class A15
    {
       public static void main(String args[])
           {
              int a=30;
              int b=45;
              int c=58;
              double s =(a+b+c)/3;
              double area=Math.sqrt(s*(s-a)*(s-b)*(s-c));
               System.out.println("The Area of the Triangle is "+area);
               
           }
    }