class Ass73{
    static void rectangleArea(int length, int breadth) {
        int area = length * breadth;
        System.out.println("Area of Rectangle = " + area);
    }
    void squareArea(int side) {
        int area = side * side;
        System.out.println("Area of Square = " + area);
    }

    public static void main(String[] args) {
        rectangleArea(8, 5);
        Ass73 obj = new Ass73();
        obj.squareArea(7);
    }
}