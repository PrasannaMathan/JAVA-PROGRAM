class Ass82rectangle
{
int width,height;
 void area1(int length, int bredth)
{
 width=length;
height=bredth;
System.out.println("The area of the rectangle is "+(length*bredth));
}
void perimeter1(int l,int b)
{
width=l;
height=b;
System.out.println("The perimeter of the rectangle is "+2*(l+b));
}
 
public static void main(String args[])
{
Ass82rectangle s1= new Ass82rectangle();

s1.area1(8,5);
s1.perimeter1(8,5);
}
}