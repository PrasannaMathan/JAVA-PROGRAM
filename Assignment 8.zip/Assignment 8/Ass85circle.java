class Ass85circle
{
double radius;
void  calculate(double r)
{ 
radius = r;
System.out.println("The radius  of the circle is:"+radius);
double area = 3.141*r*r;
System.out.println("The area of the circle is:"+area);
double circumstance = 3.141*r*2;
System.out.println("The circumstances of the circle is :"+circumstance);
}
public static void main(String args[])
{
Ass85circle s1 = new Ass85circle();

s1.calculate( 8.0);
}
}
