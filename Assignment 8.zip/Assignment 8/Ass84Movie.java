
class Ass84Movie
{
 String title,director,actor,reviews;
Ass84Movie(String t,String d, String a)
{
title = t;
director = d;
actor = a;
}
void addReviews(String r)
{
reviews = r;
}
void display()
{
System.out.println("Movies Details");
System.out.println("Title:"+title);
System.out.println("Directer:"+director);
System.out.println("Actor:"+actor);
System.out.println("Reviews:"+reviews);
}
public static void main(String args[])
{
Ass84Movie M = new Ass84Movie ("Golila","Prakash","sar");
M.addReviews("This movie is blockbluster");
M.display();
}
}

