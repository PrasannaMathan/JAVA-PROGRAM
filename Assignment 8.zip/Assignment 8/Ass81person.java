class Ass81person
{
int age;
String name;
Ass81person(int a, String b)
{
age = a;
name = b;
}
void display()
{
System.out.println(age +" " + name);
}
public static void main(String args[])
{
Ass81person p1 = new Ass81person(22,"Prasanna");
Ass81person p2 = new Ass81person(20,"Shakti");
p1.display();
p2.display();
}
}