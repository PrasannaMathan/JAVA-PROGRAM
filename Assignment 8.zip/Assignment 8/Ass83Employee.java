class Ass83Employee
{
int salary;
String name;
int hire_date;
void add(int s , String n)
{
salary = s;
name = n;
System.out.println("The salary of the Employee is "+salary);
System.out.println("The name of the Employee is "+name);

}
void calculate(int date)
{
hire_date = date;
int service = 2026-hire_date;
System.out.println("The total service years "+service);
}
public static void main(String args[])
{
Ass83Employee e1 = new Ass83Employee();
e1.add(45000,"Santosh Pradhan");
e1.calculate(2014);

}
}
