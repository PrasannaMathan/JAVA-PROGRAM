import java.lang.*;
class A24
    {
       public static void main(String args[])
           {
              int x=7;
               System.out.println("x>>3"+(x>>3));
               System.out.println("x<<2"+(x<<2));
               
           }
    }