import java.lang.*;
class A25
    {
       public static void main(String args[])
           {
              int minutes=625800;
               int days =minutes/(60*24);
               int years =days/365;
               System.out.println("years is:"+years);
               System.out.println("days are :"+days);
               
           }
    }