import java.lang.*;
class A22
    {
       public static void main(String args[])
           {
              double weight=25.00;
              double height =21.00;
              double BMI=weight/(height*height);
               System.out.println("The body mass index will be  "+BMI);
               
           }
    }