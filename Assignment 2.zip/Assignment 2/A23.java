import java.lang.*;
class A23
    {
       public static void main(String args[])
           {
              int side =6;
              int l=3;
              int b=2;
              int h=4;
              int cube =side*side*side;
int cuboid=l*b*h;
               System.out.println("The Area of cube  is "+cube);
                System.out.println("The Area of cuboid  is "+cuboid);
               
           }
    }