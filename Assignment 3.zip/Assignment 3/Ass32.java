import java.util.Scanner;
class Ass32
{
public static void main(String args[])
{
int BS,HRA,DA,gross_salary;
Scanner sc=new Scanner(System.in);
System.out.println("Enter your basic salary:");
BS=sc.nextInt();
HRA=(BS*10)/100;
DA=(BS*60)/100;
gross_salary=BS+HRA+DA;
System.out.println("The HRA is:"+HRA);
System.out.println("The DA is:"+DA);
System.out.println("The gross_salary is:"+gross_salary);
sc.close();
}
}