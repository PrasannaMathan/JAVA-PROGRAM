import java.util.Scanner;
class Ass35
{
public static void main(String args[])
{
double cost_price,sell_price,profit,loss,profit_percentage,loss_percentage;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the cost price of the product:");
cost_price=sc.nextDouble();
System.out.println("Enter the sell price of the product:");
sell_price=sc.nextDouble();

if(sell_price > cost_price)
   {
     System.out.println("The product sell in profit");
      profit=sell_price-cost_price;
      profit_percentage=(profit*100)/cost_price;
       System.out.println("The profit is :"+profit);
        System.out.println("The total profit_percentage is :"+profit_percentage);
   }

else
  {
        System.out.println("The product sell in loss");
      loss=sell_price-cost_price;
         loss_percentage=(loss*100)/cost_price;
        System.out.println("The loss is :"+loss);
          System.out.println("The total loss_percentage is :"+loss_percentage);
}
sc.close();
}
}