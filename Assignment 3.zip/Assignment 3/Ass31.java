import java.util.Scanner;
class Ass31
{
public static void main(String args[])
{
int math,phy,chem,it,bio;
float percentage;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the math mark");
math=sc.nextInt();
System.out.println("Enter the phy mark");
phy=sc.nextInt();
System.out.println("Enter the chem mark");
chem=sc.nextInt();
System.out.println("Enter the it mark");
it=sc.nextInt();
System.out.println("Enter the bio mark");
bio=sc.nextInt();
 int total=math+phy+chem+it+bio;
percentage =(total*100)/500;
System.out.println("the total marks is :"+total);
System.out.println("the total percentage is :"+percentage);
sc.close();
}
}