class Shape
{
    void getPerimeter()
    {
    }

    void getArea()
    {
    }
}

class Circle extends Shape
{
    double r = 12;
    double pi = 3.141;

    void getPerimeter()
    {
        System.out.println("The Perimeter of the Circle is: " + 2 * pi * r);
    }

    void getArea()
    {
        System.out.println("The Area of the Circle is: " + pi * r * r);
    }
}

class Ass94
{
    public static void main(String args[])
    {
        Shape s;
        s = new Circle();

        s.getPerimeter();
        s.getArea();
    }
}
