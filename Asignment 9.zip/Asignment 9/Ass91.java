class Vehicle
{
    void drive()
    {
    }
}

class Car extends Vehicle
{
    void drive()
    {
        System.out.println("Repairing a Car");
    }
}

class Ass91
{
    public static void main(String args[])
    {
        Vehicle V;
        V = new Car();
        V.drive();
    }
}
