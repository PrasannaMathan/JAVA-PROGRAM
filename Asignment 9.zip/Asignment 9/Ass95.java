class Vehicle
{
    String make, model, fuelType;
    int year;

    Vehicle(String make, String model, int year, String fuelType)
    {
        this.make = make;
        this.model = model;
        this.year = year;
        this.fuelType = fuelType;
    }

    void fuelEfficiency()
    {
        System.out.println("Fuel efficiency: 6 km/l");
    }

    void distanceTravelled()
    {
        System.out.println("Distance travelled: 50000 km");
    }

    void maximumSpeed()
    {
        System.out.println("Maximum speed: 120 km/h");
    }
}

class Car extends Vehicle
{
    Car(String make, String model, int year, String fuelType)
    {
        super(make, model, year, fuelType);
    }

    void fuelEfficiency()
    {
        System.out.println("Car fuel efficiency: 18 km/l");
    }

    void distanceTravelled()
    {
        System.out.println("Car distance travelled: 5000 km");
    }

    void maximumSpeed()
    {
        System.out.println("Car maximum speed: 180 km/h");
    }
}

class Motorcycle extends Vehicle
{
    Motorcycle(String make, String model, int year, String fuelType)
    {
        super(make, model, year, fuelType);
    }

    void fuelEfficiency()
    {
        System.out.println("Motorcycle fuel efficiency: 45 km/l");
    }

    void distanceTravelled()
    {
        System.out.println("Motorcycle distance travelled: 3000 km");
    }

    void maximumSpeed()
    {
        System.out.println("Motorcycle maximum speed: 150 km/h");
    }
}

class Truck extends Vehicle
{
    Truck(String make, String model, int year, String fuelType)
    {
        super(make, model, year, fuelType);
    }

    void fuelEfficiency()
    {
        System.out.println("Truck fuel efficiency: 8 km/l");
    }

    void distanceTravelled()
    {
        System.out.println("Truck distance travelled: 8000 km");
    }

    void maximumSpeed()
    {
        System.out.println("Truck maximum speed: 100 km/h");
    }
}

class Ass95
{
    public static void main(String args[])
    {
        Truck t = new Truck("Tata", "Prima", 2022, "Diesel");
        Car c = new Car("Toyota", "Fortuner", 2023, "Petrol");
        Motorcycle m = new Motorcycle("Honda", "Shine", 2024, "Petrol");

        System.out.println("TRUCK");
        System.out.println("Make: " + t.make + " " + t.model);
        System.out.println("Year: " + t.year);
        System.out.println("Fuel Type: " + t.fuelType);
        t.fuelEfficiency();
        t.distanceTravelled();
        t.maximumSpeed();

        System.out.println("\nCAR");
        System.out.println("Make: " + c.make + " " + c.model);
        System.out.println("Year: " + c.year);
        System.out.println("Fuel Type: " + c.fuelType);
        c.fuelEfficiency();
        c.distanceTravelled();
        c.maximumSpeed();

        System.out.println("\nMOTORCYCLE");
        System.out.println("Make: " + m.make + " " + m.model);
        System.out.println("Year: " + m.year);
        System.out.println("Fuel Type: " + m.fuelType);
        m.fuelEfficiency();
        m.distanceTravelled();
        m.maximumSpeed();
    }
}
