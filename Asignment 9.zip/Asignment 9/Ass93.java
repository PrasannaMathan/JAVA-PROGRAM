class Person
{
    String firstname, lastname;

    Person(String firstname, String lastname)
    {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    String getFirstName()
    {
        return firstname;
    }

    String getLastName()
    {
        return lastname;
    }
}

class Employee extends Person
{
    String employeeid, employeejobtitle;

    Employee(String firstname, String lastname, String employeeid,
             String employeejobtitle)
    {
        super(firstname, lastname);
        this.employeeid = employeeid;
        this.employeejobtitle = employeejobtitle;
    }

    String getEmployeeID()
    {
        return employeeid;
    }

    String getLastName()
    {
        return super.getLastName() + " (" + employeejobtitle + ")";
    }
}

class Ass93
{
    public static void main(String args[])
    {
        Employee e = new Employee("Prasanna", "Mathan", "EMP73",
                                   "AI Engineer");

        System.out.println("Firstname: " + e.getFirstName());
        System.out.println("Lastname: " + e.getLastName());
        System.out.println("Employee ID: " + e.getEmployeeID());
    }
}
