import java.lang.*;

class Ass65
{
    public static void main(String args[])
    {
        String [] arr1 = {"python", "java", "c++", "sql"};
        String [] arr2 = {"mysql", "sql", "oracle", "java"};

        System.out.println("Common elements are : ");

        for(int i = 0; i < arr1.length; i++)
        {
            for(int j = 0; j < arr2.length; j++)
            {
                if(arr1[i].equals(arr2[j]))
                {
                    System.out.print(arr1[i]+"  ");
                    break;
                }
            }
        }
    }
}