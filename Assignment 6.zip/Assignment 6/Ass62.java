   import java.util.Scanner;

class Ass62
{
    public static void main(String args[])
    {
        int sum = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a number of elements:");
        int n = sc.nextInt();

        int a[] = new int[n];

        System.out.println("Enter " + n + " elements:");

        for(int i = 0; i < n; i++)
        {
            a[i] = sc.nextInt();
        }

        for(int i = 0; i < n; i++)
        {
            sum = sum + a[i];
        }

        int average = sum / n;

        System.out.println("The Average of the elements in the array is : " + average);
    }
}