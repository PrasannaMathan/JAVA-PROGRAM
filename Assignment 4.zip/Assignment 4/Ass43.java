import java.util.Scanner;
class Ass43
{
public static void main(String args[])
{
int num;
Scanner sc=new Scanner(System.in);

System.out.println("Enter a month number:");
num=sc.nextInt();
switch(num){
case 1: 
           
case 3:  
           
case 5:
           
case 7:
            
case 8 :

case 10 :

case 12 :
System.out.println("The month is having 31 days ");
 break;
case 4 :

case 6 :

case 9 :

case 11 :
System.out.println("The month is having 30 days ");
 break;
case 2 :
System.out.println("The month is having 28 days ");
 break;

default:
System.out.println("invalid month number");         
}
sc.close();
}
}
