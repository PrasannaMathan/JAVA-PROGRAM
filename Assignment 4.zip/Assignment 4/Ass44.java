import java.util.Scanner;
class Ass44
{
public static void main(String args[])
{
double a,b,c;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the first number:");
a=sc.nextDouble();
System.out.println("Enter the second number:");
b=sc.nextDouble();
System.out.println("Enter the third number:");
c=sc.nextDouble();
if(a>b)
{
if(a>c)
{
System.out.println("A is greatest"+a);
}
else 
{
System.out.println("C is greatest"+c);
}
}
else
{
if(b>c)
{
System.out.println("B is greatest"+b);
}
else
{
System.out.println("C is greatest"+c);
}
}
sc.close();
}
}
