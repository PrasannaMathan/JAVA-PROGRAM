import java.util.Scanner;
class Ass42
{
public static void main(String args[])
{
float a,b;
Scanner sc =new Scanner(System.in);
System.out.println("Enter first number:");
a=sc.nextFloat();
System.out.println("Enter second number:");
b=sc.nextFloat();
int n1=(int)(a*1000);
int n2=(int)(b*1000);
if(n1==n2)
{
System.out.println("The numbers are same upto 3 decimal places:");
}
else
{
System.out.println("The numbers are different:");
}
sc.close();
}
}