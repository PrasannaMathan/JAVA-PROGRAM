import java.util.Scanner;
class Ass41
{
public static void main(String args[])
{
double a,b,c,d,r1,r2;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the first value:");
a=sc.nextDouble();
System.out.println("Enter the second value:");
b=sc.nextDouble();
System.out.println("Enter the third value:");
c=sc.nextDouble();
d=Math.sqrt((b*b)-4*a*c);
if(d>0)
{
r1=(-b+d)/2*a;
r2=(-b-d)/2*a;
System.out.println("Two distinct roots are:"+r1+" " +r2);
}
else if(d==0)
{
r1=-b/(2*a);
System.out.println("The both roots are same:"+r1);
}
else
{
System.out.println("Roots are imaginary");
}
sc.close();
}
}
