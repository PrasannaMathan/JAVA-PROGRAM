interface Parent1{
int a=5;
}
interface Parent2{
int b=6;
}
class Ass102Child implements Parent1,Parent2{
void display(){
System.out.println(a+" "+b);
}
public static void main(String args[]){
Ass102Child c=new Ass102Child();
c.display();
}
}
