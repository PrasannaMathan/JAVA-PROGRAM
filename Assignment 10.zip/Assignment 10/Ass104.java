class Ass104{
int rollno;
String name;
static String university="GIET";
public Ass104(int p,String q){
rollno=p;
name=q;
}
void display(){
System.out.println(rollno+"\t"+name+"\t"+university);
}
public static void main(String args[]){
Ass104 ob=new Ass104(123,"Radhe");
ob.display();
Ass104 ob1 = new Ass104(321,"Krishna");
ob1.display();
}
}
