class Ass103{
int rollno;
String name;
String sem;
public Ass103(int rollno,String name){
this.rollno=rollno;
this.name=name;
}
public Ass103(String s){
this.sem=s;
}
public Ass103(int p,String q,String s){
this.rollno=p;
this.name=q;
this.sem=s;
}
void display(){
System.out.println(rollno+"\t"+name);
}
void display1(int p,String n){
this.rollno=p;
this.name=n;
System.out.println(rollno+"\t"+name);
}
void display2(int p,String q,String s){
this.rollno=p;
this.name=q;
this.sem=s;
System.out.println(rollno+"\t"+name+"\t"+sem);
}
public static void main(String args[]){
Ass103 ob=new Ass103(123,"Ram");
ob.display();
Ass103 ob1=new Ass103(123,"Ram");
ob1.display();
Ass103 ob2=new Ass103(123,"Ram","3rd");
ob2.display2(123,"Ram","3rd");
}
}
